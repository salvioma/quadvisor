class usersModel {
    constructor(pool) {
      this.pool = pool;
    }

    //Email y contraseña introducidos correctos
    checkUser(email, password, callback) {
      this.pool.getConnection(function (err, connection) {
          if (err) {
            callback(new Error("Error"));
          } else {
            connection.query("SELECT * FROM user WHERE email=? AND password=?",
            [email, password],
              function (err, result) {
                connection.release();
                if (err) {
                  callback(new Error("Error"));
                } else if (result.length==0){
                  callback(null, null);
                }else{
                  callback(null, result);
                }
              }
            );
          }
        });
    }

    getConsultantsByArea(areaName, callback) {
      this.pool.getConnection(function (err, connection) {
          if (err) {
            callback(new Error("Error"));
          } else {
            connection.query("SELECT C.id, C.name, C.surname, C.description, C.photo FROM consultant C JOIN area A WHERE A.name = ? AND A.id = C.areaId",
            [areaName],
              function (err, result) {
                connection.release(); 
                if (err) {
                  callback(new Error("Error"));
                } else {
                  callback(null, result);
                }
              }
            );
          }
        });
    }


    getConsultantById(consultantId, callback) {
        this.pool.getConnection(function (err, connection) {
            if (err) {
              callback(new Error("Error"));
            } else {
              connection.query("SELECT * FROM consultant WHERE id = ? ",
              [consultantId],
                function (err, result) {
                  connection.release(); 
                  if (err) {
                    callback(new Error("Error"));
                  } else {
                    callback(null, result);
                  }
                }
              );
            }
          });
      }

      insertCompany(name, registeredName, CIF, province, locality, address, zipCode, website, phone, contactName, contactSurname, contactEmail, contactPhone, password, callback){
        //Orden de inserción: company, user, contact
        this.pool.getConnection(function (err, connection) {
          if (err) {
              callback(new Error("Error"));
          }
          else {
              connection.query("INSERT INTO company (name, registeredName, CIF, province, locality, address, zipCode, website, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ",
                  [name, registeredName, CIF, province, locality, address, zipCode, website, phone],
                  function (err, company) {
                      if (err) {
                        connection.release();
                        callback(new Error("Error"));
                      }
                      else {
                          if (company.length == 0) {
                            connection.release();
                            callback(null, false); 
                          }
                          else {
                            let userType=3; //company
                            connection.query("INSERT INTO user (email, password, userTypeId) VALUES (?,?,?)",
                              [contactEmail, password, userType], function (err, user) {
                                if (err) {
                                  connection.release();
                                  callback(new Error("Error"));
                                } else {
                                  connection.query("INSERT INTO companycontact (companyId, name, surname, phone, userId) VALUES ( ?,?, ?, ?, ?)",
                                    [company.insertId, contactName, contactSurname, contactPhone, user.insertId]);
                                  connection.release();
                                  callback(null, true);
                                }

                              });
                            callback(null, true);
                           
                          }
                      }
                  });
          }
      });
      }
}

module.exports = usersModel;
