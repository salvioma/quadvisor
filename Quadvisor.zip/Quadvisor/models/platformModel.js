class platformModel {
    constructor(pool) {
      this.pool = pool;
    }

    getCompanyProjects(companyId, callback) {
      this.pool.getConnection(function (err, connection) {
          if (err) {
            callback(new Error("Error"));
          } else {
            connection.query("SELECT id, projectName, projectDescription, DATE_FORMAT(publicationDate, '%d/%m/%Y') as date FROM companyprojects WHERE companyid = ?  ORDER BY publicationDate DESC",
              [companyId],
              function (err, result) {
                connection.release(); 
                if (err) {
                  callback(new Error("Error"));
                } else {
                  callback(null, result);
                }
              }
            );
          }
        });
    }

    getAllProjects(callback) {
      this.pool.getConnection(function (err, connection) {
          if (err) {
            callback(new Error("Error"));
          } else {
            connection.query("SELECT id, projectName, projectDescription, DATE_FORMAT(publicationDate, '%d/%m/%Y') as date FROM companyprojects ORDER BY publicationDate DESC",
              function (err, result) {
                connection.release(); 
                if (err) {
                  callback(new Error("Error"));
                } else {
                  callback(null, result);
                }
              }
            );
          }
        });
    }

    getProjectById(projectId, callback) {
      this.pool.getConnection(function (err, connection) {
          if (err) {
            callback(new Error("Error"));
          } else {
            connection.query("SELECT id, projectName, projectDescription, companyDescription, budget, DATE_FORMAT(startDate, '%d/%m/%Y') as start, DATE_FORMAT(endDate, '%d/%m/%Y') as end, draft, DATE_FORMAT(publicationDate, '%d/%m/%Y') as publication, contactPerson, department FROM companyprojects WHERE id=?", 
            [projectId],
              function (err, result) {
                connection.release(); 
                if (err) {
                  callback(new Error("Error"));
                } else {
                  callback(null, result);
                }
              }
            );
          }
        });
    }

    getAreas(callback) {
      this.pool.getConnection(function (err, connection) {
          if (err) {
            callback(new Error("Error"));
          } else {
            connection.query("SELECT * FROM area",
              function (err, result) {
                connection.release(); 
                if (err) {
                  callback(new Error("Error"));
                } else {
                  callback(null, result);
                }
              }
            );
          }
        });
    }
    
    insertProject(companyId, projectName, department, contactPerson, companyDescription, projectDescription, startDate, finishDate, budget, draft, callback) {
      this.pool.getConnection(function (err, connection) {
          if (err) {
            callback(new Error("Error"));
          } else {
            connection.query("INSERT INTO companyprojects (companyId, projectName, department, contactPerson, companyDescription, projectDescription, startDate, endDate, budget, draft) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [companyId, projectName, department, contactPerson, companyDescription, projectDescription, startDate, finishDate, budget, draft],
              function (err, result) {
                connection.release(); 
                if (err || result.length == 0) {
                  callback(new Error("Error"));
                } else {
                  callback(null, true);
                }
              }
            );
          }
        });
    }

    insertArea(name, callback) {
      this.pool.getConnection(function (err, connection) {
          if (err) {
            callback(new Error("Error"));
          } else {
            connection.query("INSERT INTO area (name) VALUES (?)",
            [name],
              function (err, result) {
                connection.release(); 
                if (err || result.length == 0) {
                  callback(new Error("Error"));
                } else {
                  callback(null, true);
                }
              }
            );
          }
        });
    }


     //Email y contraseña introducidos correctos
     checkUser(email, password, callback) {
      this.pool.getConnection(function (err, connection) {
          if (err) {
            callback(new Error("Error"));
          } else {
            connection.query("SELECT * FROM user WHERE (email=? AND password=?)",
            [email, password],
              function (err, result) {      
                  connection.release();
                  if (err) {
                      callback(new Error("Error"));
                  }
                  else if (result.length==0){
                      callback(null, null);
                  }
                  else{
                      callback(null, result);
                  }
              }
            );
          }
        });
    }

    getCompanyByUserId(userId, callback){
      this.pool.getConnection(function (err, connection) {
        if (err) {
          callback(new Error("Error"));
        } else {
          connection.query("SELECT companyId FROM companycontact WHERE userId=?",
          [userId],
            function (err, result) {      
                connection.release();
                if (err) {
                    callback(new Error("Error"));
                }
                else{
                    callback(null, result);
                }
            }
          );
        }
      });
    }

    getCompanyById(id, callback){
      this.pool.getConnection(function (err, connection) {
        if (err) {
          callback(new Error("Error"));
        } else {
          connection.query("SELECT * FROM company WHERE id=?",
          [id],
            function (err, result) {      
                connection.release();
                if (err) {
                    callback(new Error("Error"));
                }
                else{
                    callback(null, result);
                }
            }
          );
        }
      });
    }

    getProjectsByName(companyId, name, callback) {
      this.pool.getConnection(function (err, connection) {
          if (err) {
            callback(new Error(err));
          } else {
            let sqlName = '%' + name + '%';
            connection.query("SELECT id, projectName, projectDescription, DATE_FORMAT(publicationDate, '%d/%m/%Y') as date FROM companyprojects WHERE companyid = ? AND projectName LIKE ? ORDER BY publicationDate DESC",
              [companyId, sqlName],
              function (err, result) {
                connection.release(); 
                if (err) {
                  callback(new Error(err));
                } else {
                  callback(null, result);
                }
              }
            );
          }
        });
    }
}

module.exports = platformModel;
