const express = require("express");
const path = require("path");
const fs = require("fs-extra");

const router = express.Router();

const platformController = require("../controllers/platformController");

router.get("/projects", platformController.getProjectsList);
router.get("/projectsAdmin", platformController.getProjectsListAdmin);
router.get("/areas", platformController.getAreas);
router.get("/newPublication", platformController.newPublication);
router.post("/newPublication", platformController.insertProject);
router.get("/project/:projectId", platformController.getProjectById);
router.post("/searchProject", platformController.searchProject);
router.get("/mensajes", platformController.mensajes);
router.get("/inicio", platformController.inicio);
router.get("/registro", platformController.registro);
router.get("/contacto", platformController.contacto);


module.exports = router;

