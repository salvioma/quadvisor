const express = require("express");
const path = require("path");
const fs = require("fs-extra");

const router = express.Router();

const platformController = require("../controllers/platformController");

router.get("/projects", platformController.getProjectsList);
router.get("/projectsAdmin", platformController.getProjectsListAdmin);
router.get("/areas", platformController.getAreas);
router.get("/newPublication", platformController.newPublication);
router.get("/project/:projectId", platformController.getProjectById);
router.get("/mensajes", platformController.mensajes);
router.get("/mensajesEnviados", platformController.mensajesEnviados);
router.get("/inicio", platformController.inicio);
router.get("/registro", platformController.registro);
router.get("/contacto/:consultantId", platformController.contacto);

router.get("/networking", platformController.networking);
router.get("/networkingError", platformController.networkingError);
router.get("/cerrarSesion", platformController.cerrarSesion);
router.get("/companiesList", platformController.companiesList);
router.get("/companiesInactiveList", platformController.companiesInactiveList);
router.get("/mensajes/:mensajeId", platformController.getMensaje);
router.get("/mensajesEnviados/:mensajeEnviadoId", platformController.getMensajeEnviado);

router.post("/contacto/:consultantMensId", platformController.nuevoMensaje);
router.post("/newPublication", platformController.insertProject);
router.post("/searchProject", platformController.searchProject);
router.post("/networking", platformController.checkUser);
//router.post("/newUser", platformController.newUser);

module.exports = router;

