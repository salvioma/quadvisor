const express = require("express");
const path = require("path");
const fs = require("fs-extra");

const router = express.Router();

const usersController = require("../controllers/usersController");

router.get("/consultants/:areaName", usersController.getConsultantsByArea);
router.get("/:consultantArea/consultantDetails/:consultantId", usersController.getConsultantById);
router.get("/perfil", usersController.getCompanyDetails);

module.exports = router; 


