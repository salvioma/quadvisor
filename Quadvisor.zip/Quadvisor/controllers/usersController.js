const usersModel = require("../models/usersModel");
const mysql = require("mysql");
const config = require("../config");

const pool = mysql.createPool(config.mysqlConfig);
const usersM = new usersModel(pool);

module.exports = {
    
    getConsultantsByArea(request, response, next) {
        usersM.getConsultantsByArea(request.params.areaName, function (err, data) {
            if (err) {
                next(err);
            } else {
                let consultantsList = new Array();

                for (let element of data) {
                    
                    let consultant = {
                        id: element.id,
                        name: element.name,
                        surname: element.surname,
                        description: element.description,
                        photo:element.photo,
                        area: request.params.areaName
                    };

                    consultantsList.push(consultant);
                }

                response.render("consultants", { consultantsList });
            }
        });
    },

    getCompanyDetails(request, response, next) {
        response.render("companyDetails");
    },

    getConsultantById(request, response, next) {
        usersM.getConsultantById(request.params.consultantId, function (err, data) {
            if (err) {
                next(err);
            } else {
                let element = data[0];

                let consultant = {
                    id: element.id,
                    name: element.name,
                    surname: element.surname,
                    NIF: element.NIF,
                    phone: element.phone,
                    areaId: element.areaId,
                    userId: element.userId,
                    description: element.description,
                    photo:element.photo,
                    area: request.params.consultantArea
                }

                response.render("consultantDetails", { consultant });
            }
        });
    },
};