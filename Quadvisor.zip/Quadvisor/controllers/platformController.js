const platformModel = require("../models/platformModel");
const mysql = require("mysql");
const config = require("../config");
const req = require("express/lib/request");
const { clearCookie } = require("express/lib/response");

var photo;

const crypto = require("crypto");
const authTokens = {};
const generateAuthToken = () => {
    return crypto.randomBytes(30).toString('hex');
}

const pool = mysql.createPool(config.mysqlConfig);
const platformM = new platformModel(pool);

module.exports = {
    
    getProjectsList(request, response, next) {
        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking")
        }
        
        platformM.getCompanyProjects(request.cookies['companyId'], function (err, data) {
            if (err) {
                next(err);
            } else {
                let projectsList = new Array();

                for (let element of data) {
                    
                    let project = {
                        id: element.id,
                        projectName: element.projectName,
                        projectDescription: element.projectDescription,
                        publicationDate: element.date,
                    };

                    projectsList.push(project);
                }

                response.render("projectsList", { projectsList });
            }
        });
    },

    getProjectsListAdmin(request, response, next) {

        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking")
        }
    
        platformM.getAllProjects(function (err, data) {
            if (err) {
                next(err);
            } else {
                let projectsList = new Array();

                for (let element of data) {
                    
                    let project = {
                        id: element.id,
                        projectName: element.projectName,
                        projectDescription: element.projectDescription,
                        publicationDate: element.date,
                    };

                    projectsList.push(project);
                }

                response.render("projectsListAdmin", { projectsList });
            }
        });
    },

    getProjectById(request, response, next) {

        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking")
        }

        platformM.getProjectById(request.params.projectId, function (err, data) {
            if (err) {
                next(err);
            } else {
                let element = data[0];

                let project = {
                    id: element.id,
                    projectName: element.projectName,
                    department: element.department,
                    contactPerson: element.contactPerson,
                    companyDescription: element.companyDescription,
                    projectDescription: element.projectDescription,
                    startDate: element.start,
                    endDate: element.end,
                    budget: element.budget,
                    draft: element.draft,
                    publicationDate: element.publication
                }

                response.render("projectDetails", { project });
            }
        });
    },

    getAreas(request, response, next) {

        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking")
        }

        platformM.getAreas(function (err, data) {
            if (err) {
                next(err);
            } else {
                let areasList = new Array();

                for (let element of data) {
                    let area = {
                        id: element.id,
                        name: element.name,
                    };

                    areasList.push(area);
                }

                response.render("areas", { areasList });
            }
        });
    },

    newPublication(request, response, next) {

        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking")
        }

        response.render("newPublication");
    },

    mensajes(request, response, next) {

        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking")
        }

            response.render("mensajes");
    },

    mensajesEnviados(request, response, next) {

        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking")
        }

            response.render("mensajesEnviados");
    },

    
    inicio(request, response, next) {
            const authToken = request.cookies['AuthToken'];
            request.user = authTokens[authToken];
            let user = request.user;
    
            if(user==null){
                response.redirect("/quadvisor/networking")
            }
    
            platformM.getCompanyByUserId(user.id, function (err, data) {
                if (err) {
                    next(err);
                } else {
                    
                    response.cookie('companyId', data[0].companyId);
                    //console.log(request.cookies['companyId']);
                    //response.render("inicio", {user});

                    platformM.getCompanyById(request.cookies['companyId'], function (err, datados) {
                        if (err) {
                            next(err);
                        } else {
                            //console.log(datados);
                            response.cookie('company', datados[0]);
                            //console.log(request.cookies['company']);
                            //console.log(request.cookies['company'].photo);
                            global.photo = request.cookies['company'].photo;
                            //sleep(500);
                            //console.log(request.cookies['company']);
                            //console.log(request.cookies['company'].photo);
                            //console.log(datados);
                            response.render("inicio");
                    }});

                }});        
      
    },

    cerrarSesion(request, response, next) {

        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking")
        }

        response.cookie('AuthToken', null);
        response.cookie('AuthTokens', null);
        response.cookie('companyId', null);
        response.cookie('company', null);
        global.photo = "noProfile.png";
        response.redirect("/quadvisor/networking")
        
    },

    registro(request, response, next) {

        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking")
        }

        response.render("registro");
    },

    contacto(request, response, next) {

        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking")
        }

        response.render("contacto");
    },

    networking(request, response, next) {
        response.render("networking");
    },

    networkingError(request, response, next) {
        response.render("networkingError");
    },
    

    insertProject(request, response, next) {

        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking")
        }

        let projectName = request.body.projectName;
        let department = request.body.department;
        let contactPerson = request.body.contactPerson;
        let companyDescription = request.body.companyDescription;
        let projectDescription = request.body.projectDescription;
        let startDate = request.body.startDate;
        let endDate = request.body.endDate;
        let budget = request.body.budget;
        let draft = 0;

        //if(request.body.draft) draft = 1;
        
        platformM.insertProject(1, projectName, department, contactPerson, companyDescription, projectDescription, startDate, endDate, budget, draft, function (err, data) {
            if (err) {
                next(err);
            } else {
                response.redirect("/quadvisor/projects");
            }
        });
      },

      insertArea(request, response, next) {
        let name = request.body.name;
    
        platformM.insertArea(name, function (err, data) {
            if (err) {
                next(err);
            } else {
                response.redirect("/quadvisor/areas");
            }
        });
      },

      checkUser(request, response, next){
        let email = request.body.email;
        let password = request.body.password;

            platformM.checkUser(email, password, function(err, data){
                if (err) {
                    next(err);
                }

                else if (data == null) {
                    response.redirect("/quadvisor/networkingError");
                }

                else{

                    const authToken = generateAuthToken();
                    authTokens[authToken] = data[0];
                    
                    response.cookie('AuthToken', authToken);
                    response.cookie('AuthTokens', authTokens);

                    global.photo = "noProfile.png";

                    response.redirect("/quadvisor/inicio");
                }

            });
    },

      searchProject(request, response, next) {
        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking")
        }

        let name = request.body.projectName;
        platformM.getProjectsByName(1, name, function (err, data) {
            if (err) {
                next(err);
            } else {
                let projectsList = new Array();

                for (let element of data) {
                    
                    let project = {
                        id: element.id,
                        projectName: element.projectName,
                        projectDescription: element.projectDescription,
                        publicationDate: element.date,
                    };

                    projectsList.push(project);
                }
                response.render("projectsListByName", { projectsList, name});
            }
        });
      },
};
