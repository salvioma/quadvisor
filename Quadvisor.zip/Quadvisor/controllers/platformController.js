const platformModel = require("../models/platformModel");
const mysql = require("mysql");
const config = require("../config");

const pool = mysql.createPool(config.mysqlConfig);
const platformM = new platformModel(pool);

module.exports = {
    getProjectsList(request, response, next) {
        platformM.getCompanyProjects(1, function (err, data) {
            if (err) {
                next(err);
            } else {
                let projectsList = new Array();

                for (let element of data) {
                    
                    let project = {
                        id: element.id,
                        projectName: element.projectName,
                        projectDescription: element.projectDescription,
                        publicationDate: element.date,
                    };

                    projectsList.push(project);
                }

                response.render("projectsList", { projectsList });
            }
        });
    },

    getProjectsListAdmin(request, response, next) {
        platformM.getAllProjects(function (err, data) {
            if (err) {
                next(err);
            } else {
                let projectsList = new Array();

                for (let element of data) {
                    
                    let project = {
                        id: element.id,
                        projectName: element.projectName,
                        projectDescription: element.projectDescription,
                        publicationDate: element.date,
                    };

                    projectsList.push(project);
                }

                response.render("projectsListAdmin", { projectsList });
            }
        });
    },

    getProjectById(request, response, next) {
        platformM.getProjectById(request.params.projectId, function (err, data) {
            if (err) {
                next(err);
            } else {
                let element = data[0];

                let project = {
                    id: element.id,
                    projectName: element.projectName,
                    department: element.department,
                    contactPerson: element.contactPerson,
                    companyDescription: element.companyDescription,
                    projectDescription: element.projectDescription,
                    startDate: element.start,
                    endDate: element.end,
                    budget: element.budget,
                    draft: element.draft,
                    publicationDate: element.publication
                }

                response.render("projectDetails", { project });
            }
        });
    },

    getAreas(request, response, next) {
        platformM.getAreas(function (err, data) {
            if (err) {
                next(err);
            } else {
                let areasList = new Array();

                for (let element of data) {
                    let area = {
                        id: element.id,
                        name: element.name,
                    };

                    areasList.push(area);
                }

                response.render("areas", { areasList });
            }
        });
    },

    newPublication(request, response, next) {
        response.render("newPublication");
    },

    insertProject(request, response, next) {
        let projectName = request.body.projectName;
        let department = request.body.department;
        let contactPerson = request.body.contactPerson;
        let companyDescription = request.body.companyDescription;
        let projectDescription = request.body.projectDescription;
        let startDate = request.body.startDate;
        let endDate = request.body.endDate;
        let budget = request.body.budget;
        let draft = 0;

        //if(request.body.draft) draft = 1;
        
        platformM.insertProject(1, projectName, department, contactPerson, companyDescription, projectDescription, startDate, endDate, budget, draft, function (err, data) {
            if (err) {
                next(err);
            } else {
                response.redirect("/quadvisor/projects");
            }
        });
      },


      insertArea(request, response, next) {
        let name = request.body.name;
    
        platformM.insertArea(name, function (err, data) {
            if (err) {
                next(err);
            } else {
                response.redirect("/quadvisor/areas");
            }
        });
      },

      searchProject(request, response, next) {
        let name = request.body.projectName;
        platformM.getProjectsByName(1, name, function (err, data) {
            if (err) {
                next(err);
            } else {
                let projectsList = new Array();

                for (let element of data) {
                    
                    let project = {
                        id: element.id,
                        projectName: element.projectName,
                        projectDescription: element.projectDescription,
                        publicationDate: element.date,
                    };

                    projectsList.push(project);
                }
                response.render("projectsListByName", { projectsList, name});
            }
        });
      },
};