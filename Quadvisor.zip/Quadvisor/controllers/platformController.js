const platformModel = require("../models/platformModel");
const mysql = require("mysql");
const config = require("../config");
const req = require("express/lib/request");
const { clearCookie, redirect } = require("express/lib/response");

var photo;

const crypto = require("crypto");
const authTokens = {};
const generateAuthToken = () => {
    return crypto.randomBytes(30).toString('hex');
}

const pool = mysql.createPool(config.mysqlConfig);
const platformM = new platformModel(pool);

module.exports = {
    
    getProjectsList(request, response, next) {
        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking");
        }

        else if (global.userType != 3){
            response.redirect("/quadvisor/inicio");
        }
        
        platformM.getCompanyProjects(request.cookies['companyId'], function (err, data) {
            if (err) {
                next(err);
            } else {
                let projectsList = new Array();

                for (let element of data) {
                    
                    let project = {
                        id: element.id,
                        projectName: element.projectName,
                        projectDescription: element.projectDescription,
                        publicationDate: element.date,
                    };

                    projectsList.push(project);
                }

                response.render("projectsList", { projectsList });
            }
        });
    },

    getProjectsListAdmin(request, response, next) {

        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking");
        }
    
        else if (global.userType != 3){
            response.redirect("/quadvisor/inicio");
        }

        platformM.getAllProjects(function (err, data) {
            if (err) {
                next(err);
            } else {
                let projectsList = new Array();

                for (let element of data) {
                    
                    let project = {
                        id: element.id,
                        projectName: element.projectName,
                        projectDescription: element.projectDescription,
                        publicationDate: element.date,
                    };

                    projectsList.push(project);
                }

                response.render("projectsListAdmin", { projectsList });
            }
        });
    },

    getProjectById(request, response, next) {

        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking");
        }

        else if (global.userType != 3){
            response.redirect("/quadvisor/inicio");
        }

        platformM.getProjectById(request.params.projectId, function (err, data) {
            if (err) {
                next(err);
            } else {
                let element = data[0];

                let project = {
                    id: element.id,
                    projectName: element.projectName,
                    department: element.department,
                    contactPerson: element.contactPerson,
                    companyDescription: element.companyDescription,
                    projectDescription: element.projectDescription,
                    startDate: element.start,
                    endDate: element.end,
                    budget: element.budget,
                    draft: element.draft,
                    publicationDate: element.publication
                }

                response.render("projectDetails", { project });
            }
        });
    },

    getAreas(request, response, next) {

        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking");
        }

        else if (global.userType != 3){
            response.redirect("/quadvisor/inicio");
        }

        platformM.getAreas(function (err, data) {
            if (err) {
                next(err);
            } else {
                let areasList = new Array();

                for (let element of data) {
                    let area = {
                        id: element.id,
                        name: element.name,
                    };

                    areasList.push(area);
                }

                response.render("areas", { areasList });
            }
        });
    },

    newPublication(request, response, next) {

        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking");
        }

        else if (global.userType != 3){
            response.redirect("/quadvisor/inicio");
        }

        response.render("newPublication");
    },

    mensajes(request, response, next) {

        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking");
        }

        platformM.getMensajes(user.id, function (err, data) {
            if (err) {
                next(err);
            } else {
                
                let mensajes = new Array();

                for(let element of data){

                    let mensaje = {

                        id : element.id,
                        idEmisor: element.idEmisor,
                        emailEmisor: "",
                        idReceptor: element.idReceptor,
                        fecha: element.fecha,
                        asunto: element.asunto,
                        cuerpo: element.cuerpo


                    };


                    platformM.getEmailEmisor(mensaje.idEmisor, function (err, data) {
                        if (err) {
                            next(err);
                        } else {
        
                            mensaje.emailEmisor = data[0].email;
                            
                        }});      
                    
                    mensajes.push(mensaje);
            }

            response.render("mensajes", {mensajes});
        
        }
    });        

    },

    mensajesEnviados(request, response, next) {

        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking");
        }

        platformM.getMensajesEnviados(user.id, function (err, data) {
            if (err) {
                next(err);
            } else {
                
                let mensajes = new Array();

                for(let element of data){

                    let mensaje = {

                        id : element.id,
                        idEmisor: element.idEmisor,
                        idReceptor: element.idReceptor,
                        emailReceptor: "",
                        fecha: element.fecha,
                        asunto: element.asunto,
                        cuerpo: element.cuerpo

                    };

                    mensajes.push(mensaje);
            }

            response.render("mensajesEnviados", {mensajes});
        
        }
    });        
    },

    
    inicio(request, response, next) {
            const authToken = request.cookies['AuthToken'];
            request.user = authTokens[authToken];
            let user = request.user;
    
            if(user==null){
                response.redirect("/quadvisor/networking");
		//response.redirect("www.google.com");
            }

            //El usuario es un consultor
            else if(user.userTypeId == 1){

                platformM.getConsultantByUserId(user.id, function (err, data) {
                    if (err) {
                        next(err);
                    } else {

                        global.photo = data[0].photo;
                        global.userType = user.userTypeId;
                        response.render("inicio");

                    }});
            }

            //El usuario es una empresa o administrador
            else{

                platformM.getCompanyByUserId(user.id, function (err, data) {
                    if (err) {
                        next(err);
                    } else {
                        
                        response.cookie('companyId', data[0].companyId);
                        //console.log(request.cookies['companyId']);
                        //response.render("inicio", {user});

                        platformM.getCompanyById(data[0].companyId, function (err, datados) {
                            if (err) {
                                next(err);
                            } else {
                                //console.log(datados);
                                response.cookie('company', datados[0]);
                                //console.log(request.cookies['company']);
                                //console.log(request.cookies['company'].photo);
                                global.photo = datados[0].photo;
                                global.userType = user.userTypeId;
                                //sleep(500);
                                //console.log(request.cookies['company']);
                                //console.log(request.cookies['company'].photo);
                                //console.log(datados);
                                response.render("inicio");
                        }});

                    }});   

            }
      
    },

    cerrarSesion(request, response, next) {

        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking");
        }

        response.cookie('AuthToken', null);
        response.cookie('AuthTokens', null);
        response.cookie('companyId', null);
        response.cookie('company', null);
        global.photo = "noProfile.png";
        global.userType = 1;
        response.redirect("/quadvisor/networking");
        
    },

    registro(request, response, next) {

        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking");
        }

        response.render("registro");
    },

    contacto(request, response, next) {

        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking");
        }

        let userId = request.params.userId;
        response.render("contacto", {userId});

    },

    networking(request, response, next) {
        response.render("networking");
    },

    networkingError(request, response, next) {
        response.render("networkingError");
    },
    

    insertProject(request, response, next) {

        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking");
        }

        else if (global.userType != 3){
            response.redirect("/quadvisor/inicio");
        }

        let projectName = request.body.projectName;
        let department = request.body.department;
        let contactPerson = request.body.contactPerson;
        let companyDescription = request.body.companyDescription;
        let projectDescription = request.body.projectDescription;
        let startDate = request.body.startDate;
        let endDate = request.body.endDate;
        let budget = request.body.budget;
        let draft = 0;

        //if(request.body.draft) draft = 1;
        
        platformM.insertProject(1, projectName, department, contactPerson, companyDescription, projectDescription, startDate, endDate, budget, draft, function (err, data) {
            if (err) {
                next(err);
            } else {
                response.redirect("/quadvisor/projects");
            }
        });
      },

      insertArea(request, response, next) {

        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking");
        }

        

        let name = request.body.name;
    
        platformM.insertArea(name, function (err, data) {
            if (err) {
                next(err);
            } else {
                response.redirect("/quadvisor/areas");
            }
        });
      },

      checkUser(request, response, next){

        let emailSU = request.body.emailSU;
        let passwordSU = request.body.passSU;

        /*El usuario está introduciendo datos de Inicio de Sesión*/
        if (typeof emailSU === 'undefined' && typeof passwordSU === 'undefined'){

        let email = request.body.email;
        let password = request.body.password;

        
            platformM.checkUser(email, password, function(err, data){
                if (err) {
                    next(err);
                }
                
            
                else if (data == null) {
                    let active = 1;
                    response.render("networkingError", { active } );

                }

                else if (data[0].Active == 0) {
                    let active = 0;
                    response.render("networkingError", { active } );

                }

                else{

                    const authToken = generateAuthToken();
                    authTokens[authToken] = data[0];
                    
                    response.cookie('AuthToken', authToken);
                    response.cookie('AuthTokens', authTokens);

                    global.photo = "noProfile.png";
                    global.userType = 1;

                    response.redirect("/quadvisor/inicio");
                }

            });

        }

        /*El usuario está completando el formulario de Registro */
        else{

            //console.log(emailSU);
            //console.log(passwordSU);

            let passwordCSU = request.body.passCSU;

            if (passwordSU != passwordCSU){
                let active = 1;
                response.render("networkingError", { active } );
            }

            /*Se da de alta al usuario (empresa) en la Base de Datos. La cuenta está inicialmente inactiva*/
            platformM.insertUser(emailSU, passwordSU, 3, 0, function (err, data) {
                if (err) {
                    next(err);
                } else {

                    let userId = data.insertId;
                    //console.log(userId);

                    let nameComp = request.body.nameComp;
                    let regNameComp = request.body.regNameComp;
                    let CIFComp = request.body.CIFComp;
                    let provinceComp = request.body.provinceComp;
                    let localityComp = request.body.localityComp;
                    let addressComp = request.body.addressComp;
                    let zipComp = request.body.zipComp;
                    let webComp = request.body.webComp;
                    let phoneComp = request.body.phoneComp;

                    /*Añadir la compañia en la base de datos*/
                    platformM.insertCompany(nameComp, regNameComp, CIFComp, provinceComp, localityComp, addressComp, zipComp, webComp, phoneComp,  function (err, data) {
                        if (err) {
                            next(err);
                        } else {

                            let companyId = data.insertId;
                            let nameContact = request.body.nameContact;
                            let surnameContact = request.body.surnameContact;
                            let phoneContact= request.body.phoneContact;
                            //console.log(companyId);
        
                            /*Añadir el contacto de la compañia */
                            platformM.insertCompanyContact(companyId, nameContact, surnameContact, phoneContact, userId,  function (err, data) {
                                if (err) {
                                   next(err);
                                } else {

                                    
                                    const date = new Date();
                                    let asunto = "Solicitud de nuevo usuario";
                                    let cuerpo = nameComp + " (CIF: " + CIFComp + ")";

                                    platformM.nuevaSolicitud(userId, date, asunto, cuerpo, function (err, data) {
                                        if (err) {
                                           next(err);
                                        } else {

                                            response.redirect("/quadvisor/networking");

                                        }
                                    });
                                }
                            });
                   
                        }
                    });
                }
            });
        }
    },
  
    companiesList(request, response, next){
        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking");
        }
        
        else if (global.userType != 2){
            response.redirect("/quadvisor/inicio");
        }

        let companies = new Array();

        platformM.getCompaniesActiveContactList(function (err, data){
            if (err){
                next(err);
            }
            else{

                for(let element of data){

                    let company = {
                        name: element.name,
                        province: element.province,
                        locality: element.locality,
                        photo: element.photo
                    }

                    companies.push(company);
                    //console.log("company");
                    //console.log(company);
                    
                }

                response.render("companiesList", {companies});
                //console.log(companies);

                //for(let company of companies){

                   // companies.splice(0, 1); //Elimina 1 elemento desde la posicion 0

                //}

            }
        });  
           
    },


    companiesInactiveList(request, response, next){
        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null ){
            response.redirect("/quadvisor/networking");
        }

        else if (user.userTypeId != 2){
            response.redirect("/quadvisor/inicio");
        }
        
        let companies = new Array();

        platformM.getCompaniesInactiveContactList(function (err, data){
            if (err){
                next(err);
            }
            else{

                for(let element of data){

                    let company = {
                        name: element.name,
                        province: element.province,
                        locality: element.locality,
                        photo: element.photo
                    }

                    companies.push(company);
                    //console.log("company");
                    //console.log(company);
                    
                }

                response.render("companiesList", {companies});
                //console.log(companies);

                //for(let company of companies){

                   // companies.splice(0, 1); //Elimina 1 elemento desde la posicion 0

                //}

            }
        });  
           
    },

      searchProject(request, response, next) {
        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking");
        }

        else if (user.userTypeId == 3){
            response.redirect("/quadvisor/inicio");
        }

        let name = request.body.projectName;
        platformM.getProjectsByName(1, name, function (err, data) {
            if (err) {
                next(err);
            } else {
                let projectsList = new Array();

                for (let element of data) {
                    
                    let project = {
                        id: element.id,
                        projectName: element.projectName,
                        projectDescription: element.projectDescription,
                        publicationDate: element.date,
                    };

                    projectsList.push(project);
                }
                response.render("projectsListByName", { projectsList, name});
            }
        });
      },

      getMensaje(request, response, next){
        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking");
        }

        platformM.getMensajeById(request.params.mensajeId, function (err, data) {
            if (err) {
                next(err);
            } else {

                let mensaje = data[0];

                platformM.getUserTypeByUserId(mensaje.idEmisor, function (err, data) {

                    if (err) {
                        next(err);
                    } else {

                        let userType = data[0].userTypeId;

                        if (userType == 1){

                            platformM.getConsultantByUserId(mensaje.idEmisor, function (err, data) {

                                if (err) {
                                    next(err);
                                } else {

                                    let mensajeInfo = {
                                        name: data[0].name + " " + data[0].surname,
                                        telef: data[0].phone
                                    }
                                    

                                response.render("mensajesDetails", { mensaje, mensajeInfo });
                                }
                            });

                        }

                        else{

                            platformM.getCompanyByUserId(mensaje.idEmisor, function (err, data) {

                                let compId = data[0].companyId;

                                if (err) {
                                    next(err);
                                } else {
    
                                    platformM.getCompanyById(compId, function (err, data) {

                                        if (err) {
                                            next(err);
                                        } else {
            
                                            let nameInfo = data[0].name;
                                            let phoneInfo = data[0].phone; 

                                            let companyInfo = {
                                                registeredName: data[0].registeredName,
                                                CIF: data[0].CIF,
                                                province: data[0].province,
                                                locality: data[0].locality,
                                                address: data[0].address,
                                                zipCode: data[0].zipCode,
                                                website: data[0].website
                                            }


                                            platformM.getCompanyContactById(compId, function (err, data) {

                                                if (err) {
                                                    next(err);
                                                } else {

                                                   

                                                    let solicitudInfo = {
                                                        name: data[0].name,
                                                        surname: data[0].surname,
                                                        phone: data[0].phone,
                                                        userId: data[0].userId
                                                    }

                                                    let mensajeInfo = {
                                                        name: nameInfo,
                                                        telef: phoneInfo,
                                                        company: companyInfo,
                                                        solicitud: solicitudInfo
                                                    }

                                                    response.render("mensajesDetails", { mensaje, mensajeInfo });
                                                }
                                            });

                                            
                                        }
                                    });
                                }
                            });
                        }
                    }

                });
            }
            
        });

    },

    getMensajeEnviado(request, response, next){
        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking");
        }

        platformM.getMensajeById(request.params.mensajeEnviadoId, function (err, data) {
            if (err) {
                next(err);
            } else {

                let mensaje = data[0];

                platformM.getUserTypeByUserId(mensaje.idReceptor, function (err, data) {

                    if (err) {
                        next(err);
                    } else {

                        let userType = data[0].userTypeId;

                        if (userType == 1){

                            platformM.getConsultantByUserId(mensaje.idReceptor, function (err, data) {

                                if (err) {
                                    next(err);
                                } else {

                                    let mensajeInfo = {
                                        name: data[0].name + " " + data[0].surname,
                                        telef: data[0].phone
                                    }
    
                                response.render("mensajesEnviadosDetails", { mensaje, mensajeInfo });
                                }
                            });

                        }

                        else{

                            platformM.getCompanyByUserId(mensaje.idReceptor, function (err, data) {

                                let compId = data[0].companyId;

                                if (err) {
                                    next(err);
                                } else {
    
                                    platformM.getCompanyById(compId, function (err, data) {

                                        if (err) {
                                            next(err);
                                        } else {
            
                                            let mensajeInfo = {
                                                name: data[0].name,
                                                telef: data[0].phone
                                            }
            
                                        response.render("mensajesEnviadosDetails", { mensaje, mensajeInfo });
                                        }
                                    });
                                }
                            });
                        }
                    }

                });
            }
            
        });

    },

    nuevoMensaje(request, response, next){

        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking");
        }

        let receptor = request.params.consultantMensId;
        let auxReceptor = parseInt(receptor, 10);
        
        let mensaje ={


            receptorId: auxReceptor,
            userId: user.id,
            asunto: request.body.asuntoMensaje,
            cuerpo: request.body.cuerpoMensaje    

        }

        //console.log(mensaje);
        const date = new Date();
       
        platformM.nuevoMensajeBD(mensaje.userId, mensaje.receptorId, date, mensaje.asunto, mensaje.cuerpo, function (err, data) {
            if (err) {
                next(err);
            } else {
                
                response.redirect("/quadvisor/areas");

            }
        });
    },

    altaUsuario(request, response, next) {
        const authToken = request.cookies['AuthToken'];
        request.user = authTokens[authToken];
        let user = request.user;

        if(user==null){
            response.redirect("/quadvisor/networking");
        }

        else if (user.userTypeId == 3){
            response.redirect("/quadvisor/inicio");
        }

        let userAlta = request.params.userAltaId;

        platformM.setAltaUsuario(userAlta, function (err, data) {
            if (err) {
                next(err);
            } else {
                
                response.redirect("/quadvisor/inicio");

            }
        });

    }

};
