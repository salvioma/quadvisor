-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3307
-- Tiempo de generación: 19-01-2022 a las 18:34:22
-- Versión del servidor: 10.4.16-MariaDB
-- Versión de PHP: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `quadvisor`
--
CREATE DATABASE IF NOT EXISTS `quadvisor` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `quadvisor`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `area`
--

CREATE TABLE IF NOT EXISTS `area` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `area`
--

INSERT INTO `area` (`id`, `name`) VALUES
(7, 'Estrategia'),
(4, 'Finanzas'),
(1, 'Gobierno corporativo'),
(8, 'Internacionalización'),
(6, 'Legal'),
(3, 'Marketing'),
(5, 'Recursos Humanos'),
(2, 'Riesgos'),
(9, 'Ventas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `company`
--

CREATE TABLE IF NOT EXISTS `company` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `registeredName` varchar(50) NOT NULL,
  `CIF` int(9) NOT NULL,
  `province` varchar(50) NOT NULL,
  `locality` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `zipCode` int(5) NOT NULL,
  `website` varchar(50) NOT NULL,
  `phone` int(9) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `company`
--

INSERT INTO `company` (`id`, `name`, `registeredName`, `CIF`, `province`, `locality`, `address`, `zipCode`, `website`, `phone`) VALUES
(1, 'Fatz', 'Fatz', 12345678, 'New York', 'New York', 'Blue Bill Park Road', 84633, 'fatz.com', 842563028),
(2, 'Pixope', 'Pixope', 12345678, 'Bogojevo', 'Bogojevo', 'Harper Circle', 233, 'pixope.com', 926818636),
(3, 'Oodoo', 'Oodoo', 12345678, 'Tres Isletas', 'Tres Isletas', 'Kinsman Road', 56, 'oodoo.com', 791620327),
(4, 'Skajo', 'Skajo', 12345678, 'Dijon', 'Dijon', 'Nova Junction', 35384, 'skajo.com', 281943071);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `companycontact`
--

CREATE TABLE IF NOT EXISTS `companycontact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `companyId` int(30) NOT NULL,
  `name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `phone` int(9) NOT NULL,
  `userId` int(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idUser` (`userId`),
  KEY `companyId` (`companyId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `companycontact`
--

INSERT INTO `companycontact` (`id`, `companyId`, `name`, `surname`, `phone`, `userId`) VALUES
(1, 1, 'Quinn ', 'Johns', 558327003, 1),
(2, 2, 'Matteo ', 'Bennie', 926818636, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `companyprojects`
--

CREATE TABLE IF NOT EXISTS `companyprojects` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `companyId` int(30) NOT NULL,
  `projectName` varchar(200) NOT NULL,
  `department` varchar(500) NOT NULL,
  `contactPerson` varchar(500) NOT NULL,
  `companyDescription` varchar(900) NOT NULL,
  `projectDescription` varchar(900) NOT NULL,
  `startDate` date NOT NULL,
  `endDate` date NOT NULL,
  `budget` int(20) NOT NULL,
  `draft` tinyint(4) NOT NULL,
  `publicationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `companyId` (`companyId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `companyprojects`
--

INSERT INTO `companyprojects` (`id`, `companyId`, `projectName`, `department`, `contactPerson`, `companyDescription`, `projectDescription`, `startDate`, `endDate`, `budget`, `draft`, `publicationDate`) VALUES
(1, 1, 'Proyecto1', 'Departamento1', 'Persona1', 'Descripción de la empresa 1', 'Descripción del proyecto 1', '2022-01-08', '2022-05-20', 12345, 0, '2022-01-07 10:40:47'),
(2, 1, 'Proyecto2', 'Departamento2', 'Persona2', 'Descripción de la empresa 2', 'Descripción del proyecto 2', '2022-01-01', '2022-01-31', 123456, 0, '2022-01-07 10:38:09'),
(4, 2, 'Proyecto3', 'Departamento3', 'Persona3', 'Descripción de la empresa 3', 'Descripción del proyecto 3', '2022-01-05', '2022-01-28', 12345, 0, '2022-01-07 10:41:41'),
(5, 1, 'Proyecto de prueba', 'RRHH', 'Hugo López', 'Descripción de prueba de empresa 1', 'Descripción de prueba de proyecto 1', '2022-01-14', '2022-01-25', 4554645, 0, '2022-01-08 18:02:32');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `consultant`
--

CREATE TABLE IF NOT EXISTS `consultant` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `NIF` varchar(9) NOT NULL,
  `phone` int(9) NOT NULL,
  `description` varchar(500) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `areaId` int(5) NOT NULL,
  `userId` int(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `areaId` (`areaId`),
  KEY `idUser` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `consultant`
--

INSERT INTO `consultant` (`id`, `name`, `surname`, `NIF`, `phone`, `description`, `photo`, `areaId`, `userId`) VALUES
(1, 'Gonzalo', 'Rodríguez ', '12345678Z', 123456789, 'Descripción consultor 1', '', 1, 3),
(2, 'Andrea', 'Pérez', '12345678Z', 123456789, 'Descripción consultor 2', '', 1, 4),
(3, 'Lucas', 'García', '12345678Z', 926818636, 'Descripción consultor 3', '', 2, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `userTypeId` int(5) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userTypeId` (`userTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `user`
--

INSERT INTO `user` (`id`, `email`, `password`, `userTypeId`) VALUES
(1, 'quinnjohns@gmail.com', '12345', 3),
(2, 'matteobennie@gmail.com', '12345', 3),
(3, 'gonzalo@gmail.com', '12345', 1),
(4, 'andrea@gmail.com', '12345', 1),
(5, 'lucas@gmail.com', '12345', 1),
(7, 'carlos@gmail.com', '12345', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usertype`
--

CREATE TABLE IF NOT EXISTS `usertype` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `type` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usertype`
--

INSERT INTO `usertype` (`id`, `type`) VALUES
(1, 'consultant'),
(2, 'administrator'),
(3, 'company');

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `companycontact`
--
ALTER TABLE `companycontact`
  ADD CONSTRAINT `companycontact_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `companycontact_ibfk_3` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `companyprojects`
--
ALTER TABLE `companyprojects`
  ADD CONSTRAINT `companyprojects_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `consultant`
--
ALTER TABLE `consultant`
  ADD CONSTRAINT `consultant_ibfk_1` FOREIGN KEY (`areaId`) REFERENCES `area` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `consultant_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`userTypeId`) REFERENCES `usertype` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
