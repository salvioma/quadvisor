"use strict"

$(function(){
	//¿toogle?
	
  $("#signUpForm").hide();
  
  $("#signUp").click(function(){
     $("#signInForm").hide();
     $("#signUpForm").show();
  });
  
  $("#signIn").click(function(){
     $("#signUpForm").hide();
     $("#signInForm").show();
  });
});