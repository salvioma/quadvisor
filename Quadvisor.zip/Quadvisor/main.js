const express = require("express");
const path = require("path");
const config = require("./config");
const platformRouter = require("./routers/platformRouter");
const usersRouter = require("./routers/usersRouter");

const app = express();

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(express.static(path.resolve("public")));
app.use(express.urlencoded({ extended: true }));

app.use("/quadvisor", platformRouter);
app.use("/users", usersRouter);

app.use(function(request, response, next) {
    response.status(404);
    let err="404";
    response.render("error", {err});
});

app.use(function (error, request, response, next) {
    response.status(500);
    let err = "500";
    response.render("error", {err});
});

app.listen(config.port, function (err) {
    if (err) {
        console.log("ERROR al iniciar el servidor");
    }
});
