"use strict";

module.exports = {
    mysqlConfig: {
        host: "db-quadvisor.ct2aq8zlkunx.us-east-1.rds.amazonaws.com", 
        user: "admin",
        password: "Vashthe778!", 
        database: "quadvisor", 
        port: 3306
    },
    port: 3000
}