"use strict";

module.exports = {
    mysqlConfig: {
        host: "localhost", 
        user: "root",
        password: "", 
        database: "quadvisor", 
        port: 3306
    },
    port: 3000
}